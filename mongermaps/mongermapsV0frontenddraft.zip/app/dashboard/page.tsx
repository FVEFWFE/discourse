import { Shell } from "@/components/shell"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { DataTable } from "@/components/data-table"
import { columns } from "@/components/intel-columns"
import { AlertTriangle, TrendingUp, Target, ArrowUp, PlusCircle, X } from "lucide-react"

const kpiData = [
  {
    title: "Pattaya Vibe Shift (24h)",
    value: "+0.2",
    subtext: "Player Score™ rising",
    analysisText: "Analysis based on 184 new reports",
    positive: true,
  },
  {
    title: "Fair Price: Soi 6 ST",
    value: "1300 THB",
    subtext: "No significant change",
    touristPrice: "2000 THB",
    positive: null,
  },
  {
    title: "New Reports Processed (6h)",
    value: "184",
    subtext: "From 43 venues",
    positive: null,
  },
  {
    title: "Active Scam Alerts",
    value: "3",
    subtext: "Pattaya Zone",
    positive: false,
  },
]

const intelData = [
  {
    id: "1",
    time: "14m ago",
    venue: "Kinnaree",
    district: "Soi 6",
    playerScore: 9.4,
    pricePaid: "1500 THB",
    service: "ST",
    tags: ["GFE", "BBFS"],
  },
  {
    id: "2",
    time: "28m ago",
    venue: "Sapphire A Go Go",
    district: "Walking Street",
    playerScore: 9.2,
    pricePaid: "2000 THB",
    service: "LT",
    tags: ["GFE"],
  },
  {
    id: "3",
    time: "45m ago",
    venue: "Insomnia (FL)",
    district: "LK Metro",
    playerScore: 8.9,
    pricePaid: "1200 THB",
    service: "ST",
    tags: ["Starfish"],
  },
  {
    id: "4",
    time: "1h ago",
    venue: "Dollhouse",
    district: "Soi 6",
    playerScore: 7.8,
    pricePaid: "1400 THB",
    service: "ST",
    tags: ["GFE", "BBFS"],
  },
  {
    id: "5",
    time: "1h ago",
    venue: "Windmill",
    district: "Walking Street",
    playerScore: 6.2,
    pricePaid: "1800 THB",
    service: "LT",
    tags: ["Starfish"],
  },
]

const gamePlanData = [
  { name: "Kinnaree", score: 9.4 },
  { name: "Sapphire A Go Go", score: 9.2 },
  { name: "Insomnia (FL)", score: 8.9 },
]

const watchlistData = [
  { name: "Sapphire A Go Go", score: 9.2 },
  { name: "Kinnaree", score: 9.4 },
  { name: "King Club", score: 4.5 },
]

export default function Dashboard() {
  return (
    <Shell>
      <div className="p-4 md:p-6 space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-2xl md:text-3xl font-bold">Intelligence Briefing</h1>
          <p className="text-muted-foreground mt-1">Last updated: 7 minutes ago via automated scrape</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {kpiData.map((kpi, index) => (
            <Card key={index}>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">{kpi.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center space-x-2">
                  <div
                    className={`text-2xl font-bold ${
                      kpi.positive === true
                        ? "text-green-500"
                        : kpi.positive === false
                          ? "text-red-500"
                          : "text-foreground"
                    }`}
                  >
                    {kpi.value}
                  </div>
                  {kpi.positive === true && <ArrowUp className="h-5 w-5 text-green-500" />}
                </div>
                <p
                  className={`text-xs mt-1 ${
                    kpi.positive === true
                      ? "text-green-500"
                      : kpi.positive === false
                        ? "text-red-500"
                        : "text-muted-foreground"
                  }`}
                >
                  {kpi.subtext}
                </p>
                {kpi.touristPrice && <p className="text-xs mt-1 text-red-500">Tourist Price: {kpi.touristPrice}</p>}
                {kpi.analysisText && <p className="text-xs mt-1 text-muted-foreground">{kpi.analysisText}</p>}
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-4 gap-6">
          {/* Tonight's Watchlist */}
          <div className="xl:order-1 order-2">
            <Card>
              <CardHeader>
                <CardTitle className="text-sm flex items-center gap-2">
                  <Target className="h-4 w-4" />
                  Tonight's Watchlist
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {watchlistData.map((venue, index) => (
                  <div key={index} className="flex justify-between items-center group">
                    <div className="flex items-center space-x-2">
                      <span className="text-sm">{venue.name}</span>
                      <Badge
                        variant={venue.score > 8.5 ? "default" : venue.score > 7 ? "secondary" : "destructive"}
                        className={venue.score > 8.5 ? "bg-green-500" : ""}
                      >
                        {venue.score}
                      </Badge>
                    </div>
                    <Button variant="ghost" size="sm" className="opacity-0 group-hover:opacity-100 h-6 w-6 p-0">
                      <X className="h-3 w-3" />
                    </Button>
                  </div>
                ))}
                <Button variant="outline" size="sm" className="w-full mt-2 bg-transparent">
                  <PlusCircle className="h-4 w-4 mr-2" />
                  Add Venue
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Main Intel Feed */}
          <div className="xl:col-span-2 xl:order-2 order-1">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5" />
                  Live Intel Feed
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center space-x-2">
                  <Input placeholder="Filter by venue..." className="max-w-sm" />
                </div>
                <div className="overflow-x-auto">
                  <DataTable columns={columns} data={intelData} />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Right Sidebar */}
          <div className="space-y-4 xl:order-3 order-3">
            <Card>
              <CardHeader>
                <CardTitle className="text-sm flex items-center gap-2">
                  <Target className="h-4 w-4" />
                  Tonight's Game Plan
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {gamePlanData.map((venue, index) => (
                  <div key={index} className="flex justify-between items-center group">
                    <div className="flex items-center space-x-2">
                      <span className="text-sm">{venue.name}</span>
                      <Badge
                        variant={venue.score > 8.5 ? "default" : venue.score > 7 ? "secondary" : "destructive"}
                        className={venue.score > 8.5 ? "bg-green-500" : ""}
                      >
                        {venue.score}
                      </Badge>
                    </div>
                    <Button variant="ghost" size="sm" className="opacity-0 group-hover:opacity-100 h-6 w-6 p-0">
                      <X className="h-3 w-3" />
                    </Button>
                  </div>
                ))}
                <Button variant="outline" size="sm" className="w-full mt-2 bg-transparent">
                  <PlusCircle className="h-4 w-4 mr-2" />
                  Add Venue
                </Button>
              </CardContent>
            </Card>

            <Card className="border-red-500/50">
              <CardHeader className="bg-red-500/10">
                <CardTitle className="text-sm flex items-center gap-2 text-red-500">
                  <AlertTriangle className="h-4 w-4" />
                  Active Scam Alerts
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-4">
                <p className="text-sm">
                  <strong className="text-red-500">ALERT:</strong> Bill padding at 'XYZ Bar' on Walking Street.
                  <Button variant="link" className="p-0 h-auto text-red-500 ml-1 underline">
                    Open Dossier for details
                  </Button>
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </Shell>
  )
}
