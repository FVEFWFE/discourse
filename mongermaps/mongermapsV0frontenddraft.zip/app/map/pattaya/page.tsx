"use client"

import { useState } from "react"
import { Shell } from "@/components/shell"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import { Badge } from "@/components/ui/badge"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { MapPin, Route } from "lucide-react"

export default function MapPage() {
  const [venueType, setVenueType] = useState("")
  const [district, setDistrict] = useState("")
  const [scoreRange, setScoreRange] = useState([8.0])
  const [priceRange, setPriceRange] = useState([1500])
  const [selectedTags, setSelectedTags] = useState<string[]>([])
  const [showVeteranPath, setShowVeteranPath] = useState(false)

  const tags = ["GFE", "BBFS", "Starfish", "BBBJ", "CIM", "COF"]

  return (
    <Shell>
      <div className="relative h-full">
        {/* Filter Panel */}
        <Card className="absolute top-4 left-4 w-80 z-10">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MapPin className="h-5 w-5" />
              Filters
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Veteran's Path toggle */}
            <div className="flex items-center justify-between">
              <Label htmlFor="veteran-path" className="text-sm font-medium flex items-center gap-2">
                <Route className="h-4 w-4" />
                Show Veteran's Path
              </Label>
              <Switch id="veteran-path" checked={showVeteranPath} onCheckedChange={setShowVeteranPath} />
            </div>

            <div>
              <Label className="text-sm font-medium">Venue Type</Label>
              <Select value={venueType} onValueChange={setVenueType}>
                <SelectTrigger>
                  <SelectValue placeholder="All types" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="gogo">Go-Go Bar</SelectItem>
                  <SelectItem value="beer">Beer Bar</SelectItem>
                  <SelectItem value="freelancer">Freelancer Zone</SelectItem>
                  <SelectItem value="massage">Massage Parlor</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label className="text-sm font-medium">District</Label>
              <Select value={district} onValueChange={setDistrict}>
                <SelectTrigger>
                  <SelectValue placeholder="All districts" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="walking-street">Walking Street</SelectItem>
                  <SelectItem value="soi-6">Soi 6</SelectItem>
                  <SelectItem value="lk-metro">LK Metro</SelectItem>
                  <SelectItem value="soi-buakhao">Soi Buakhao</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label className="text-sm font-medium">Player Score™ Range</Label>
              <div className="px-2 py-4">
                <Slider
                  value={scoreRange}
                  onValueChange={setScoreRange}
                  max={10}
                  min={1}
                  step={0.1}
                  className="w-full"
                />
                <div className="flex justify-between text-xs text-muted-foreground mt-1">
                  <span>1.0</span>
                  <span className="font-medium">{scoreRange[0]}</span>
                  <span>10.0</span>
                </div>
              </div>
            </div>

            <div>
              <Label className="text-sm font-medium">Price Range (THB)</Label>
              <div className="px-2 py-4">
                <Slider
                  value={priceRange}
                  onValueChange={setPriceRange}
                  max={5000}
                  min={500}
                  step={100}
                  className="w-full"
                />
                <div className="flex justify-between text-xs text-muted-foreground mt-1">
                  <span>500</span>
                  <span className="font-medium">{priceRange[0]}</span>
                  <span>5000</span>
                </div>
              </div>
            </div>

            <div>
              <Label className="text-sm font-medium mb-3 block">Tags</Label>
              <div className="grid grid-cols-2 gap-2">
                {tags.map((tag) => (
                  <div key={tag} className="flex items-center space-x-2">
                    <Checkbox
                      id={tag}
                      checked={selectedTags.includes(tag)}
                      onCheckedChange={(checked) => {
                        if (checked) {
                          setSelectedTags([...selectedTags, tag])
                        } else {
                          setSelectedTags(selectedTags.filter((t) => t !== tag))
                        }
                      }}
                    />
                    <Label htmlFor={tag} className="text-sm">
                      {tag}
                    </Label>
                  </div>
                ))}
              </div>
            </div>

            <Button className="w-full bg-transparent" variant="outline">
              Reset Filters
            </Button>
          </CardContent>
        </Card>

        {/* Map Placeholder with Sample Markers */}
        <div className="h-full bg-muted flex items-center justify-center relative">
          {/* Sample venue markers with enhanced popovers */}
          <div className="absolute top-1/3 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="ghost" className="p-0 h-auto">
                  <div className="w-6 h-6 bg-green-500 rounded-full border-2 border-white shadow-lg cursor-pointer hover:scale-110 transition-transform" />
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-80">
                <div className="space-y-3">
                  <h1 className="text-lg font-bold">Sapphire A Go Go</h1>
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-muted-foreground">Player Score™:</span>
                    <Badge className="bg-green-500 text-lg px-3 py-1">9.2</Badge>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-muted-foreground">Fair Price (ST):</span>
                    <span className="font-semibold">1800 THB</span>
                  </div>
                  <div className="flex flex-wrap gap-1">
                    <Badge variant="secondary" className="text-xs">
                      GFE
                    </Badge>
                    <Badge variant="secondary" className="text-xs">
                      BBFS
                    </Badge>
                    <Badge variant="secondary" className="text-xs">
                      BBBJ
                    </Badge>
                  </div>
                  <Button className="w-full" size="sm">
                    View Full Dossier
                  </Button>
                </div>
              </PopoverContent>
            </Popover>
          </div>

          <div className="absolute top-1/2 left-1/3 transform -translate-x-1/2 -translate-y-1/2">
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="ghost" className="p-0 h-auto">
                  <div className="w-6 h-6 bg-green-500 rounded-full border-2 border-white shadow-lg cursor-pointer hover:scale-110 transition-transform" />
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-80">
                <div className="space-y-3">
                  <h1 className="text-lg font-bold">Kinnaree</h1>
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-muted-foreground">Player Score™:</span>
                    <Badge className="bg-green-500 text-lg px-3 py-1">9.4</Badge>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-muted-foreground">Fair Price (ST):</span>
                    <span className="font-semibold">1500 THB</span>
                  </div>
                  <div className="flex flex-wrap gap-1">
                    <Badge variant="secondary" className="text-xs">
                      GFE
                    </Badge>
                    <Badge variant="secondary" className="text-xs">
                      BBFS
                    </Badge>
                  </div>
                  <Button className="w-full" size="sm">
                    View Full Dossier
                  </Button>
                </div>
              </PopoverContent>
            </Popover>
          </div>

          {/* Veteran's path visualization */}
          {showVeteranPath && (
            <svg className="absolute inset-0 w-full h-full pointer-events-none">
              <defs>
                <filter id="glow">
                  <feGaussianBlur stdDeviation="3" result="coloredBlur" />
                  <feMerge>
                    <feMergeNode in="coloredBlur" />
                    <feMergeNode in="SourceGraphic" />
                  </feMerge>
                </filter>
              </defs>
              <path
                d="M 33% 50% Q 50% 30% 50% 33%"
                stroke="#10b981"
                strokeWidth="3"
                fill="none"
                strokeDasharray="5,5"
                filter="url(#glow)"
                className="animate-pulse"
              />
            </svg>
          )}

          <div className="text-center">
            <MapPin className="h-16 w-16 mx-auto mb-4 text-muted-foreground" />
            <h3 className="text-lg font-semibold mb-2">Interactive Map</h3>
            <p className="text-muted-foreground">
              Map integration would display venue markers here
              <br />
              Color-coded by Player Score™ and filtered by selected criteria
            </p>
          </div>
        </div>
      </div>
    </Shell>
  )
}
