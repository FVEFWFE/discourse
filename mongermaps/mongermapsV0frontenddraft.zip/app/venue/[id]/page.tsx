"use client"

import { Shell } from "@/components/shell"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from "recharts"
import { Shield, TrendingUp, Lightbulb } from "lucide-react"

// Sample data for charts
const scoreData = [
  { date: "Jan 1", score: 8.2 },
  { date: "Jan 8", score: 8.5 },
  { date: "Jan 15", score: 9.1 },
  { date: "Jan 22", score: 9.4 },
  { date: "Jan 29", score: 9.2 },
]

const tagData = [
  { tag: "GFE", frequency: 78 },
  { tag: "BBFS", frequency: 45 },
  { tag: "BBBJ", frequency: 67 },
  { tag: "CIM", frequency: 23 },
  { tag: "Starfish", frequency: 5 },
]

export default function VenuePage() {
  return (
    <Shell>
      <div className="p-6 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Kinnaree</h1>
            <p className="text-muted-foreground">Soi 6 • Go-Go Bar</p>
          </div>
          <Badge className="bg-green-500 text-xl px-4 py-2">9.4</Badge>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5" />
              Intelligence Summary
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-green-500">
                  <TrendingUp className="h-4 w-4" />
                  <span className="font-semibold text-sm">Verdict</span>
                </div>
                <p className="text-sm">
                  A high-value G-Club with consistently excellent Player Scores, but be prepared for a slightly older
                  crowd.
                </p>
              </div>
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-blue-500">
                  <Shield className="h-4 w-4" />
                  <span className="font-semibold text-sm">Threat Assessment</span>
                </div>
                <p className="text-sm">Low. No recent scam reports. Staff is friendly to Westerners.</p>
              </div>
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-yellow-500">
                  <Lightbulb className="h-4 w-4" />
                  <span className="font-semibold text-sm">Insider Tip</span>
                </div>
                <p className="text-sm">
                  Veterans report that negotiating price is difficult here; better to accept the listed price which is
                  usually fair.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Player Score™ Over Time</CardTitle>
              <p className="text-sm text-muted-foreground">Last 30 days trend analysis</p>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={scoreData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis domain={[7, 10]} />
                  <Tooltip />
                  <Line
                    type="monotone"
                    dataKey="score"
                    stroke="#10b981"
                    strokeWidth={3}
                    dot={{ fill: "#10b981", strokeWidth: 2, r: 4 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Reported Tags Frequency</CardTitle>
              <p className="text-sm text-muted-foreground">Based on verified reports</p>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={tagData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="tag" />
                  <YAxis />
                  <Tooltip formatter={(value) => [`${value}%`, "Frequency"]} />
                  <Bar dataKey="frequency" fill="#10b981" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>

        {/* Recent Reports */}
        <Card>
          <CardHeader>
            <CardTitle>Recent Intelligence Reports</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="border-l-4 border-green-500 pl-4 py-2">
                <div className="flex items-center justify-between mb-2">
                  <Badge className="bg-green-500">9.4</Badge>
                  <span className="text-sm text-muted-foreground">2 hours ago</span>
                </div>
                <p className="text-sm">Excellent service, very accommodating. Fair price at 1500 THB for ST.</p>
                <div className="flex gap-1 mt-2">
                  <Badge variant="secondary" className="text-xs">
                    GFE
                  </Badge>
                  <Badge variant="secondary" className="text-xs">
                    BBFS
                  </Badge>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </Shell>
  )
}
